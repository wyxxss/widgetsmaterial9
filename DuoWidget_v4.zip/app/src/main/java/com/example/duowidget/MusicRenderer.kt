package com.example.duowidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Рисует музыкальный виджет шестью белыми масками (слоями). Каждый слой в layout
 * красится своим системным цветом через tint, поэтому цвета сами следуют за обоями/темой.
 * Все координаты ниже — в dp, холст уже отмасштабирован.
 */
object MusicRenderer {
    private const val TAU = 6.2831855f

    class Layers(
        val deco: Bitmap, val pbg: Bitmap, val fg: Bitmap,
        val sub: Bitmap, val pf: Bitmap, val trk: Bitmap
    )

    class Input(
        val title: String, val artist: String, val cover: Bitmap?,
        val playing: Boolean, val posMs: Long, val durMs: Long, val halloween: Boolean
    )

    // ---------- шрифт ----------
    private val fonts = HashMap<Int, Typeface>()

    private fun font(ctx: Context, weight: Int): Typeface {
        fonts[weight]?.let { return it }
        var t: Typeface? = null
        for (name in arrayOf("GoogleSansFlex.ttf", "RobotoFlex.ttf")) {
            val path = "fonts/$name"
            try {
                t = Typeface.Builder(ctx.assets, path)
                    .setFontVariationSettings("'wght' $weight").build()
            } catch (e: Exception) { t = null }
            if (t == null) {
                try { t = Typeface.Builder(ctx.assets, path).build() } catch (e: Exception) { t = null }
            }
            if (t != null) break
        }
        val r = t ?: Typeface.create("sans-serif", if (weight >= 600) Typeface.BOLD else Typeface.NORMAL)
        fonts[weight] = r
        return r
    }

    private fun tp(ctx: Context, size: Float, weight: Int) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = size
        typeface = font(ctx, weight)
    }

    // ---------- кэш маски обложки ----------
    private var mCover: Bitmap? = null
    private var mMask: Bitmap? = null

    private fun coverMask(cover: Bitmap): Bitmap {
        val cached = mMask
        if (cover === mCover && cached != null) return cached
        val m = ImageEngine.mask(cover, 256, 256, 0.5f, 0.5f, 40, false)
        mCover = cover; mMask = m
        return m
    }

    // ---------- фигуры ----------
    /** Волнистый контур: n выступов. sx/sy сплющивают (тыква шире, чем выше). */
    private fun blob(n: Int, r: Float, a: Float, sx: Float, sy: Float): Path {
        val p = Path()
        val steps = 140
        for (k in 0..steps) {
            val q = TAU * k / steps
            val rr = r * (1f + a * cos(n * q))
            val x = rr * cos(q) * sx
            val y = rr * sin(q) * sy
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private fun facePath() = Path().apply {
        moveTo(-28f, -6f); lineTo(-12f, -6f); lineTo(-20f, -22f); close()
        moveTo(12f, -6f); lineTo(28f, -6f); lineTo(20f, -22f); close()
        moveTo(-4f, 5f); lineTo(4f, 5f); lineTo(0f, -3f); close()
        moveTo(-30f, 14f); lineTo(-22f, 22f); lineTo(-14f, 14f); lineTo(-6f, 22f)
        lineTo(2f, 14f); lineTo(10f, 22f); lineTo(18f, 14f); lineTo(30f, 14f)
        quadTo(24f, 38f, 0f, 38f); quadTo(-24f, 38f, -30f, 14f); close()
    }

    private fun stemPath() = Path().apply {
        moveTo(-4f, -50f); quadTo(-3f, -66f, 7f, -69f)
        lineTo(11f, -62f); quadTo(5f, -60f, 5f, -50f); close()
    }

    private fun webPath(): Path {
        val p = Path()
        val s = 46f
        for (k in 0..4) {
            val a = k * TAU / 16f
            p.moveTo(0f, 0f); p.lineTo(s * cos(a), s * sin(a))
        }
        for (r in floatArrayOf(14f, 26f, 38f)) {
            for (k in 0 until 4) {
                val a = k * TAU / 16f
                val b = (k + 1) * TAU / 16f
                val m = (a + b) / 2f
                p.moveTo(r * cos(a), r * sin(a))
                p.quadTo(r * 0.84f * cos(m), r * 0.84f * sin(m), r * cos(b), r * sin(b))
            }
        }
        return p
    }

    private fun batPaths(k: Float): Pair<Path, Path> {
        val l = Path().apply {
            moveTo(-1.5f, 0f); cubicTo(-5f, -8f * k - 1f, -10f, -8f * k, -14f, -3f * k + 1f)
            lineTo(-11f, 3f); lineTo(-8f, 1f); lineTo(-5f, 4f); lineTo(-2f, 2f); close()
        }
        val r = Path().apply {
            moveTo(1.5f, 0f); cubicTo(5f, -8f * k - 1f, 10f, -8f * k, 14f, -3f * k + 1f)
            lineTo(11f, 3f); lineTo(8f, 1f); lineTo(5f, 4f); lineTo(2f, 2f); close()
        }
        return Pair(l, r)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    // ---------- основная отрисовка ----------
    fun render(ctx: Context, wDp: Float, hDp: Float, outW: Int, outH: Int, inp: Input): Layers {
        val d = outW / wDp
        fun bmp() = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val layers = Layers(bmp(), bmp(), bmp(), bmp(), bmp(), bmp())
        fun cv(b: Bitmap) = Canvas(b).also { it.scale(d, d) }
        val cDeco = cv(layers.deco)
        val cPbg = cv(layers.pbg)
        val cFg = cv(layers.fg)
        val cSub = cv(layers.sub)
        val cPf = cv(layers.pf)
        val cTrk = cv(layers.trk)

        val hw = inp.halloween
        val playing = inp.playing
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }

        // --- геометрия ---
        val padX = 18f
        val btnH = 58f
        val btnB = 16f
        val buttonsTop = hDp - btnB - btnH
        val waveY = buttonsTop - 24f
        val full = hDp >= 225f
        val s = min(1f, (waveY - 14f) / 128f)          // масштаб тыквы под высоту виджета
        val cx = wDp - 30f * s
        val cy = 2f + 68f * s
        val textTop = 20f
        val textMaxW = cx - 66f * s - padX - 8f

        // --- фоновый цветок (+ паутинка) ---
        cDeco.save()
        cDeco.translate(wDp - 21f * s, cy - 43f * s)
        cDeco.drawPath(blob(10, 92f * s, if (playing) 0.17f else 0.10f, 1f, 1f), fill)
        cDeco.restore()
        if (hw) {
            stroke.strokeWidth = 1.2f
            cDeco.drawPath(webPath(), stroke)
        }

        // --- кольца от обложки + искры (только пока играет) ---
        if (playing && !hw) {
            val ring = Paint(stroke)
            val ph = (inp.posMs % 3000L) / 3000f
            for (k in 0..1) {
                val t = (ph + k * 0.5f) % 1f
                ring.strokeWidth = 2.2f
                ring.alpha = ((1f - t) * 120f).toInt().coerceIn(0, 255)
                cDeco.drawCircle(cx, cy, (62f + t * 64f) * s, ring)
            }
            val w = sin(inp.posMs / 1000f * 2f)
            fun star(x: Float, y: Float, r: Float) {
                val q = Path()
                q.moveTo(x, y - r); q.quadTo(x, y, x + r, y); q.quadTo(x, y, x, y + r)
                q.quadTo(x, y, x - r, y); q.quadTo(x, y, x, y - r); q.close()
                cDeco.drawPath(q, fill)
            }
            star(cx - 84f * s, cy + 44f * s + 3f * w, 7f)
            star(cx - 62f * s, cy + 70f * s - 3f * w, 4.5f)
            star(cx + 10f * s, cy - 78f * s + 2f * w, 4f)
        }

        // --- тыква / cookie ---
        val shape = if (hw)
            blob(8, 57f, if (playing) 0.075f else 0.04f, 1.1f, 0.94f)
        else
            blob(9, 62f, if (playing) 0.085f else 0f, 1f, 1f)
        val tilt = if (hw && playing) -5f else 0f
        // форма-печенье крутится вместе со временем трека (обложка внутри не вращается)
        val spin = if (hw || !playing) 0f else (inp.posMs / 1000f * 14f) % 360f
        val shapeR = if (spin != 0f) Path(shape).also { it.transform(Matrix().apply { setRotate(spin) }) } else shape

        cPbg.save(); cPbg.translate(cx, cy); cPbg.scale(s, s); cPbg.rotate(tilt)
        cPbg.drawPath(shapeR, fill)
        if (hw && !playing) cPbg.drawPath(facePath(), clear)
        cPbg.restore()

        cFg.save(); cFg.translate(cx, cy); cFg.scale(s, s); cFg.rotate(tilt)
        // обрезаем по форме через слой + DST_IN: у clipPath на bitmap-холсте рваный край
        cFg.saveLayer(RectF(-72f, -72f, 72f, 72f), null)
        val cover = inp.cover
        if (cover != null) {
            cFg.drawBitmap(coverMask(cover), null, RectF(-70f, -70f, 70f, 70f), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            stroke.strokeWidth = 6f
            cFg.drawCircle(0f, 0f, 44f, stroke)
            cFg.drawCircle(0f, 0f, 24f, stroke)
            cFg.drawCircle(0f, 0f, 7f, fill)
        }
        val dstIn = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        cFg.drawPath(shapeR, dstIn)
        if (hw && !playing) cFg.drawPath(facePath(), clear)
        cFg.restore()   // слой
        cFg.restore()

        if (hw) {
            cPf.save(); cPf.translate(cx, cy); cPf.scale(s, s); cPf.rotate(tilt)
            cPf.drawPath(stemPath(), fill)
            cPf.restore()
        }

        // --- эквалайзер + исполнитель ---
        val heights = if (playing) floatArrayOf(0.85f, 0.5f, 1f) else floatArrayOf(0.3f, 0.3f, 0.3f)
        for (i in 0..2) {
            val h = 14f * heights[i]
            val left = padX + i * 6f
            cPf.drawRoundRect(RectF(left, textTop + 15f - h, left + 4f, textTop + 15f), 2f, 2f, fill)
        }
        val artistP = tp(ctx, 13f, 500)
        val artistX = padX + 24f
        val artistTxt = TextUtils.ellipsize(inp.artist, artistP, textMaxW - 24f, TextUtils.TruncateAt.END)
        val chipR = artistX + artistP.measureText(artistTxt, 0, artistTxt.length) + 10f
        cDeco.drawRoundRect(RectF(padX - 8f, textTop - 4f, chipR, textTop + 19f), 11.5f, 11.5f, fill)
        cSub.drawText(artistTxt, 0, artistTxt.length, artistX, textTop + 11f, artistP)

        // --- название ---
        val titleSize = if (full) 31f else 26f
        val titleLines = if (full) 2 else 1
        val titleP = tp(ctx, titleSize, 700).apply { letterSpacing = -0.025f }
        val layout = StaticLayout.Builder
            .obtain(inp.title, 0, inp.title.length, titleP, textMaxW.toInt().coerceAtLeast(40))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(titleLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setLineSpacing(0f, 0.95f)
            .setIncludePad(false)
            .build()
        cFg.save(); cFg.translate(padX, textTop + if (full) 26f else 22f)
        layout.draw(cFg)
        cFg.restore()

        // --- время ---
        val timeP = tp(ctx, 13f, 600)
        val cur = fmt(inp.posMs)
        cFg.drawText(cur, padX, waveY + 4.5f, timeP)
        val totP = tp(ctx, 13f, 600).apply { textAlign = Paint.Align.RIGHT }
        cSub.drawText(if (inp.durMs > 0) fmt(inp.durMs) else "—", wDp - padX, waveY + 4.5f, totP)

        // --- волна прогресса ---
        val x0 = padX + 34f
        val x1 = wDp - padX - 34f
        val prog = if (inp.durMs > 0) (inp.posMs.toFloat() / inp.durMs).coerceIn(0f, 1f) else 0f
        val xp = (x0 + (x1 - x0) * prog).coerceIn(x0 + 8f, x1 - 8f)
        val amp = if (playing) 5f else 0f
        val phase = inp.posMs / 1000f * 1.3f
        fun wy(x: Float) = waveY + amp * sin(x / 24f * TAU - phase)

        stroke.strokeWidth = 6f
        val gap = if (hw) 16f else 6f
        val wave = Path()
        wave.moveTo(x0, wy(x0))
        var x = x0
        while (x <= xp - gap) { wave.lineTo(x, wy(x)); x += 1.5f }
        cPf.drawPath(wave, stroke)

        val trackStart = xp + if (hw) 16f else 8f
        if (x1 - trackStart > 1f) cTrk.drawLine(trackStart, waveY, x1, waveY, stroke)

        if (hw) {
            val k = if (playing) (if ((inp.posMs / 5000) % 2 == 0L) 0.8f else -0.6f) else -0.3f
            val (bl, br) = batPaths(k)
            cPf.save(); cPf.translate(xp, wy(xp) - 1f); cPf.scale(1.15f, 1.15f)
            cPf.drawPath(bl, fill); cPf.drawPath(br, fill)
            cPf.drawOval(RectF(-2.6f, -3.2f, 2.6f, 5.2f), fill)
            val ears = Path().apply {
                moveTo(-2.4f, -2f); lineTo(-2.8f, -6.5f); lineTo(0f, -3.6f)
                lineTo(2.8f, -6.5f); lineTo(2.4f, -2f); close()
            }
            cPf.drawPath(ears, fill)
            cPf.restore()
        } else {
            cPf.drawRoundRect(RectF(xp - 2.5f, waveY - 10f, xp + 2.5f, waveY + 10f), 2.5f, 2.5f, fill)
        }
        return layers
    }
}
