package com.example.duowidget

import androidx.compose.remote.creation.compose.state.RemoteFloat
import androidx.compose.remote.creation.compose.state.rememberRemoteFloat

/**
 * ЕДИНСТВЕННОЕ место, где берётся «время хоста». Лаунчер сам пересчитывает это выражение
 * на каждом кадре — поэтому всё, что от него зависит, анимируется без участия приложения.
 *
 * Если тут ошибка компиляции — API времени в alpha21 называется иначе (в старых версиях
 * это был ContinuousSec(), в remote.time). Поправь ТОЛЬКО эту функцию и пришли мне ошибку.
 */
@androidx.compose.runtime.Composable
fun rememberHostSeconds(): RemoteFloat = rememberRemoteFloat { androidx.compose.remote.creation.compose.state.ContinuousSec() }
