package com.example.duowidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.remote.creation.compose.layout.RemoteAlignment
import androidx.compose.remote.creation.compose.layout.RemoteArrangement
import androidx.compose.remote.creation.compose.layout.RemoteBox
import androidx.compose.remote.creation.compose.layout.RemoteColumn
import androidx.compose.remote.creation.compose.layout.RemoteComposable
import androidx.compose.remote.creation.compose.layout.RemoteRow
import androidx.compose.remote.creation.compose.layout.RemoteText
import androidx.compose.remote.creation.compose.modifier.RemoteModifier
import androidx.compose.remote.creation.compose.modifier.background
import androidx.compose.remote.creation.compose.modifier.clip
import androidx.compose.remote.creation.compose.modifier.fillMaxHeight
import androidx.compose.remote.creation.compose.modifier.fillMaxSize
import androidx.compose.remote.creation.compose.modifier.fillMaxWidth
import androidx.compose.remote.creation.compose.modifier.graphicsLayer
import androidx.compose.remote.creation.compose.modifier.height
import androidx.compose.remote.creation.compose.modifier.padding
import androidx.compose.remote.creation.compose.modifier.size
import androidx.compose.remote.creation.compose.modifier.width
import androidx.compose.remote.creation.compose.state.RemoteFloat
import androidx.compose.remote.creation.compose.state.abs
import androidx.compose.remote.creation.compose.state.rdp
import androidx.compose.remote.creation.compose.state.rf
import androidx.compose.remote.creation.compose.widgets.RemoteComposeWidget
import androidx.compose.remote.creation.compose.widgets.onClick
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Музыкальный виджет на Remote Compose. Анимации (вращающееся «печенье», бегущая волна,
 * эквалайзер) вычисляются лаунчером на каждом кадре. Данные трека берём из MusicState,
 * сервис MediaListenerService просит перерисовать виджет при смене трека/паузы.
 */
class MusicRcWidget : RemoteComposeWidget() {

    @RemoteComposable
    @Composable
    override fun Content(context: Context, widgetId: Int) {
        val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        fun c(res: Int) = Color(context.getColor(res))
        // системные цвета Material You (тона как в твоих music_colors.xml)
        val bg = if (night) c(android.R.color.system_accent2_800) else c(android.R.color.system_accent2_100)
        val primary = if (night) c(android.R.color.system_accent1_200) else c(android.R.color.system_accent1_600)
        val onPrimary = if (night) c(android.R.color.system_accent1_800) else c(android.R.color.system_accent1_0)
        val primaryC = if (night) c(android.R.color.system_accent1_700) else c(android.R.color.system_accent1_200)
        val tertC = if (night) c(android.R.color.system_accent3_700) else c(android.R.color.system_accent3_200)
        val onTertC = if (night) c(android.R.color.system_accent3_100) else c(android.R.color.system_accent3_800)
        val track = if (night) c(android.R.color.system_accent2_600) else c(android.R.color.system_accent2_300)
        val sub = if (night) c(android.R.color.system_accent2_200) else c(android.R.color.system_accent2_700)

        val playing = MusicState.playing
        val title = if (MusicState.title.isEmpty()) "Ничего не играет" else MusicState.title
        val artist = if (MusicState.artist.isEmpty()) "—" else MusicState.artist
        val prog = if (MusicState.durMs > 0) MusicState.posMs.toFloat() / MusicState.durMs else 0f

        val t = rememberHostSeconds()
        val spin: RemoteFloat = if (playing) t * 24f.rf else 0f.rf

        RemoteBox(
            modifier = RemoteModifier.fillMaxSize().clip(RoundedCornerShape(36.dp)).background(bg),
        ) {
            RemoteColumn(
                modifier = RemoteModifier.fillMaxSize().padding(18.dp),
                verticalArrangement = RemoteArrangement.SpaceBetween,
            ) {
                // ---- верх: плашка артиста + название | обложка-печенье ----
                RemoteRow(modifier = RemoteModifier.fillMaxWidth(), verticalAlignment = RemoteAlignment.CenterVertically) {
                    RemoteColumn(modifier = RemoteModifier.fillMaxWidth(0.62f.rf)) {
                        RemoteRow(
                            modifier = RemoteModifier.clip(RoundedCornerShape(12.dp)).background(tertC).padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = RemoteAlignment.CenterVertically,
                        ) {
                            for (i in 0 until 3) {
                                val h = 4.rf + 10.rf * wave(t, i * 7f, playing)
                                RemoteBox(RemoteModifier.width(3.rdp).height(h).clip(RoundedCornerShape(2.dp)).background(onTertC))
                                RemoteBox(RemoteModifier.width(2.rdp))
                            }
                            RemoteText(artist, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = onTertC)
                        }
                        RemoteText(title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = primary,
                            modifier = RemoteModifier.padding(top = 10.dp))
                    }
                    RemoteBox(modifier = RemoteModifier.fillMaxWidth().height(116.rdp), contentAlignment = RemoteAlignment.Center) {
                        // «печенье» = два скруглённых квадрата, повёрнутых друг к другу на 45°
                        RemoteBox(RemoteModifier.size(84.rdp).clip(RoundedCornerShape(26.dp)).background(primaryC)
                            .graphicsLayer(rotationZ = spin))
                        RemoteBox(RemoteModifier.size(84.rdp).clip(RoundedCornerShape(26.dp)).background(primaryC)
                            .graphicsLayer(rotationZ = spin + 45f.rf))
                        RemoteText("♪", fontSize = 34.sp, color = primary)
                    }
                }

                // ---- волна прогресса из столбиков ----
                RemoteRow(modifier = RemoteModifier.fillMaxWidth().height(28.rdp), verticalAlignment = RemoteAlignment.CenterVertically) {
                    RemoteText(fmt(MusicState.posMs), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = sub)
                    RemoteBox(RemoteModifier.width(8.rdp))
                    val n = 28
                    for (i in 0 until n) {
                        val done = i < (prog * n).toInt()
                        val h = if (done) 6.rf + 16.rf * wave(t, i * 6f, playing) else 4.rf
                        RemoteBox(RemoteModifier.width(5.rdp).height(h).clip(RoundedCornerShape(3.dp)).background(if (done) primary else track))
                        RemoteBox(RemoteModifier.width(2.rdp))
                    }
                    RemoteBox(RemoteModifier.width(6.rdp))
                    RemoteText(if (MusicState.durMs > 0) fmt(MusicState.durMs) else "—", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = sub)
                }

                // ---- кнопки ----
                RemoteRow(modifier = RemoteModifier.fillMaxWidth().height(58.rdp)) {
                    RemoteBox(
                        RemoteModifier.fillMaxHeight().width(86.rdp).clip(RoundedCornerShape(topStart = 29.dp, bottomStart = 29.dp, topEnd = 10.dp, bottomEnd = 10.dp))
                            .background(tertC).onClick(pi(context, MusicWidgetProvider.ACTION_PREV, 11)),
                        contentAlignment = RemoteAlignment.Center,
                    ) { RemoteText("⏮", fontSize = 22.sp, color = onTertC) }
                    RemoteBox(RemoteModifier.width(4.rdp))
                    RemoteBox(
                        RemoteModifier.fillMaxHeight().width(120.rdp).clip(RoundedCornerShape(if (playing) 29.dp else 18.dp))
                            .background(primary).onClick(pi(context, MusicWidgetProvider.ACTION_PLAY, 12)),
                        contentAlignment = RemoteAlignment.Center,
                    ) { RemoteText(if (playing) "⏸" else "▶", fontSize = 24.sp, color = onPrimary) }
                    RemoteBox(RemoteModifier.width(4.rdp))
                    RemoteBox(
                        RemoteModifier.fillMaxHeight().width(86.rdp).clip(RoundedCornerShape(topStart = 10.dp, bottomStart = 10.dp, topEnd = 29.dp, bottomEnd = 29.dp))
                            .background(tertC).onClick(pi(context, MusicWidgetProvider.ACTION_NEXT, 13)),
                        contentAlignment = RemoteAlignment.Center,
                    ) { RemoteText("⏭", fontSize = 22.sp, color = onTertC) }
                }
            }
        }
    }

    /** Треугольная волна 0..1 от времени хоста: abs(((t*40 + shift) % 40) - 20) / 20 */
    private fun wave(t: RemoteFloat, shift: Float, playing: Boolean): RemoteFloat =
        if (!playing) 0.3f.rf else abs(((t * 40f.rf + shift.rf) % 40f.rf) - 20f.rf) / 20f.rf

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun pi(ctx: Context, act: String, code: Int) = android.app.PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, MusicWidgetProvider::class.java).setAction(act),
        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
    )

    companion object {
        /** Просим систему пересоздать документ виджета (новый трек, пауза, прогресс). */
        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MusicRcWidget::class.java))
            if (ids.isEmpty()) return
            ctx.sendBroadcast(
                Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                    .setClass(ctx, MusicRcWidget::class.java)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            )
        }
    }
}
