package com.example.duowidget

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService

/**
 * Сам по себе ничего не делает с уведомлениями, но доступ к ним — единственный
 * способ получить MediaSessionManager.getActiveSessions() для чужих плееров.
 */
class MediaListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val callbacks = HashMap<MediaController, MediaController.Callback>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> setControllers(list ?: emptyList()) }

    private val tick = Runnable { refresh(fromTick = true) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        val cn = ComponentName(this, MediaListenerService::class.java)
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            setControllers(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // доступа нет
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) {}
        unregisterAll()
        handler.removeCallbacks(tick)
        MusicState.clear()
        MusicWidgetProvider.updateAll(this)
    }

    private fun unregisterAll() {
        callbacks.forEach { (c, cb) -> try { c.unregisterCallback(cb) } catch (e: Exception) {} }
        callbacks.clear()
    }

    private fun setControllers(list: List<MediaController>) {
        unregisterAll()
        controllers = list
        list.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { refresh() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
                override fun onSessionDestroyed() { refresh() }
            }
            c.registerCallback(cb, handler)
            callbacks[c] = cb
        }
        refresh()
    }

    private fun refresh(fromTick: Boolean = false) {
        handler.removeCallbacks(tick)
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()
        MusicState.load(c)
        // по таймеру не перерисовываем, пока экран выключен
        val pm = getSystemService(PowerManager::class.java)
        if (!(fromTick && !pm.isInteractive)) { MusicWidgetProvider.updateAll(this); MusicRcWidget.refresh(this) }
        // пока играет — перерисовываем каждую секунду: волна течёт, форма крутится, кольца расходятся
        if (MusicState.playing) handler.postDelayed(tick, 1_000)
    }
}
