package com.example.duowidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.ExifInterface
import android.net.Uri
import kotlin.math.max

object ImageEngine {

    /** Читает фото, уменьшает и поворачивает по EXIF. */
    fun decode(ctx: Context, uri: Uri, maxSide: Int = 1600): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        val scale = maxSide.toFloat() / max(raw.width, raw.height)
        if (scale < 1f) m.postScale(scale, scale)
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }

    /**
     * Белая маска, где прозрачность = яркость пикселя. ImageView красится tint-ом
     * в системный акцентный цвет, фон — другим системным цветом. Выходит дуотон
     * в цветах Material You, и он сам меняется при смене обоев/темы.
     */
    fun mask(
        src: Bitmap, outW: Int, outH: Int,
        offX: Float, offY: Float, contrast: Int, invert: Boolean
    ): Bitmap {
        val target = outW.toFloat() / outH
        val srcAspect = src.width.toFloat() / src.height
        val cw: Int
        val ch: Int
        if (srcAspect > target) {
            ch = src.height; cw = (ch * target).toInt()
        } else {
            cw = src.width; ch = (cw / target).toInt()
        }
        val cx = ((src.width - cw) * offX.coerceIn(0f, 1f)).toInt()
        val cy = ((src.height - ch) * offY.coerceIn(0f, 1f)).toInt()

        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src, Rect(cx, cy, cx + cw, cy + ch), Rect(0, 0, outW, outH),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )

        val px = IntArray(outW * outH)
        out.getPixels(px, 0, outW, 0, 0, outW, outH)
        val lum = FloatArray(px.size)
        val hist = IntArray(256)
        for (i in px.indices) {
            val c = px[i]
            val l = 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
            lum[i] = l
            hist[l.toInt().coerceIn(0, 255)]++
        }

        // автоуровни: отсекаем по 1% с краёв
        val cut = (px.size * 0.01f).toInt()
        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] <= cut) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] <= cut) { acc += hist[hi]; hi-- }
        if (hi - lo < 8) { lo = 0; hi = 255 }
        val range = (hi - lo).toFloat()

        val k = 0.5f + contrast / 50f
        for (i in px.indices) {
            var v = ((lum[i] - lo) / range).coerceIn(0f, 1f)
            v = ((v - 0.5f) * k + 0.5f).coerceIn(0f, 1f)
            if (invert) v = 1f - v
            val a = (v * 255f + 0.5f).toInt()
            px[i] = (a shl 24) or 0x00FFFFFF
        }
        out.setPixels(px, 0, outW, 0, 0, outW, outH)
        return out
    }
}
