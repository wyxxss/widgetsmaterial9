package com.example.duowidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.Calendar

data class Settings(
    val contrast: Int = 40,
    val offX: Float = 0.5f,
    val offY: Float = 0.5f,
    val invert: Boolean = false
)

object Store {
    private fun file(ctx: Context, id: Int) = File(ctx.filesDir, "src_$id.jpg")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    fun saveSource(ctx: Context, id: Int, bmp: Bitmap) {
        file(ctx, id).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    fun loadSource(ctx: Context, id: Int): Bitmap? {
        val f = file(ctx, id)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun save(ctx: Context, id: Int, s: Settings) {
        prefs(ctx).edit()
            .putInt("c_$id", s.contrast)
            .putFloat("x_$id", s.offX)
            .putFloat("y_$id", s.offY)
            .putBoolean("i_$id", s.invert)
            .apply()
    }

    fun load(ctx: Context, id: Int): Settings {
        val p = prefs(ctx)
        val d = Settings()
        return Settings(
            p.getInt("c_$id", d.contrast),
            p.getFloat("x_$id", d.offX),
            p.getFloat("y_$id", d.offY),
            p.getBoolean("i_$id", d.invert)
        )
    }

    fun delete(ctx: Context, id: Int) {
        file(ctx, id).delete()
        prefs(ctx).edit().remove("c_$id").remove("x_$id").remove("y_$id").remove("i_$id").apply()
    }

    /** 0 — авто (24 окт — 1 ноя), 1 — всегда, 2 — выкл */
    fun halloweenMode(ctx: Context): Int = prefs(ctx).getInt("hw_mode", 0)

    fun setHalloweenMode(ctx: Context, m: Int) {
        prefs(ctx).edit().putInt("hw_mode", m).apply()
    }

    fun halloweenActive(ctx: Context): Boolean = when (halloweenMode(ctx)) {
        1 -> true
        2 -> false
        else -> {
            val c = Calendar.getInstance()
            val m = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)
            (m == Calendar.OCTOBER && day >= 24) || (m == Calendar.NOVEMBER && day <= 1)
        }
    }
}
