package com.example.duowidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class ConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var src: Bitmap? = null

    private lateinit var img: ImageView
    private lateinit var sbContrast: SeekBar
    private lateinit var sbX: SeekBar
    private lateinit var sbY: SeekBar
    private lateinit var cbInvert: CheckBox

    private val reqPick = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        src = Store.loadSource(this, widgetId)
        val st = Store.load(this, widgetId)

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val pad = dp(20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val frame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(getColor(R.color.widget_bg))
                cornerRadius = dp(28).toFloat()
            }
            clipToOutline = true
            addView(img, FrameLayout.LayoutParams(-1, -1))
        }
        val w = resources.displayMetrics.widthPixels - pad * 2
        root.addView(frame, LinearLayout.LayoutParams(w, w / 2))

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setPadding(0, dp(16), 0, 0)
        }
        fun seek(p: Int): SeekBar = SeekBar(this).apply {
            max = 100; progress = p
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { render() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        root.addView(label("Контраст"))
        sbContrast = seek(st.contrast); root.addView(sbContrast)
        root.addView(label("Кадр: сдвиг по горизонтали"))
        sbX = seek((st.offX * 100).toInt()); root.addView(sbX)
        root.addView(label("Кадр: сдвиг по вертикали"))
        sbY = seek((st.offY * 100).toInt()); root.addView(sbY)

        cbInvert = CheckBox(this).apply {
            text = "Инвертировать (светлое ↔ тёмное)"
            isChecked = st.invert
            setOnCheckedChangeListener { _, _ -> render() }
        }
        root.addView(cbInvert)

        root.addView(Button(this).apply {
            text = "Выбрать фото"
            setOnClickListener { pickPhoto() }
        })
        root.addView(Button(this).apply {
            text = "Готово"
            setOnClickListener { save() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
        render()
        if (src == null) pickPhoto()
    }

    private fun settings() = Settings(
        contrast = sbContrast.progress,
        offX = sbX.progress / 100f,
        offY = sbY.progress / 100f,
        invert = cbInvert.isChecked
    )

    private fun render() {
        val s = src
        if (s == null) { img.setImageDrawable(null); return }
        val st = settings()
        img.setImageBitmap(ImageEngine.mask(s, 700, 350, st.offX, st.offY, st.contrast, st.invert))
        img.setColorFilter(getColor(R.color.widget_fg))
    }

    @Suppress("DEPRECATION")
    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, reqPick)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val bmp = try { ImageEngine.decode(this, uri) } catch (e: Exception) { null }
            runOnUiThread {
                if (bmp == null) {
                    Toast.makeText(this, "Не удалось открыть фото", Toast.LENGTH_SHORT).show()
                } else {
                    src = bmp
                    render()
                }
            }
        }.start()
    }

    private fun save() {
        val s = src
        if (s == null) {
            Toast.makeText(this, "Сначала выбери фото", Toast.LENGTH_SHORT).show()
            return
        }
        Store.saveSource(this, widgetId, s)
        Store.save(this, widgetId, settings())
        PhotoWidgetProvider.update(this, AppWidgetManager.getInstance(this), widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
