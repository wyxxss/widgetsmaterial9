package com.example.duowidget

import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock

/** Текущее состояние плеера. Заполняется из MediaListenerService. */
object MusicState {
    @Volatile var controller: MediaController? = null
    @Volatile var title: String = ""
    @Volatile var artist: String = ""
    @Volatile var cover: Bitmap? = null
    @Volatile var playing: Boolean = false
    @Volatile var posMs: Long = 0
    @Volatile var durMs: Long = 0

    fun clear() {
        controller = null; title = ""; artist = ""; cover = null
        playing = false; posMs = 0; durMs = 0
    }

    fun load(c: MediaController?) {
        if (c == null) { clear(); return }
        val md = c.metadata
        val ps = c.playbackState
        controller = c
        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        cover = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        durMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0
        playing = ps?.state == PlaybackState.STATE_PLAYING
        var pos = ps?.position ?: 0L
        if (pos < 0) pos = 0
        if (ps != null && playing) {
            pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
        }
        posMs = if (durMs > 0) pos.coerceIn(0, durMs) else pos
    }
}
