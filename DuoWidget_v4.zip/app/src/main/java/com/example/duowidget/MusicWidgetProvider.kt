package com.example.duowidget

import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min

class MusicWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onAppWidgetOptionsChanged(
        ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        update(ctx, mgr, id)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val c = MusicState.controller ?: return
        when (intent.action) {
            ACTION_PREV -> c.transportControls.skipToPrevious()
            ACTION_NEXT -> c.transportControls.skipToNext()
            ACTION_PLAY -> if (MusicState.playing) c.transportControls.pause() else c.transportControls.play()
        }
    }

    companion object {
        const val ACTION_PREV = "com.example.duowidget.PREV"
        const val ACTION_PLAY = "com.example.duowidget.PLAY"
        const val ACTION_NEXT = "com.example.duowidget.NEXT"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MusicWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        private fun action(ctx: Context, act: String, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, code,
                Intent(ctx, MusicWidgetProvider::class.java).setAction(act),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_music)

            val o = mgr.getAppWidgetOptions(id)
            val wDp = max(o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 320), 100)
            val hDp = max(o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 220), 180)
            val density = ctx.resources.displayMetrics.density

            // шесть слоёв-битмапов не должны превышать лимит RemoteViews (~1.5 экрана)
            val dm = ctx.resources.displayMetrics
            val budget = dm.widthPixels.toLong() * dm.heightPixels * 6L * 7L / 10L
            var outW = min((wDp * density).toInt(), 800)
            fun outHFor(w: Int) = (hDp.toFloat() * w / wDp).toInt()
            while (outW > 240 && 6L * 4L * outW * outHFor(outW) > budget) outW -= 40
            val outH = outHFor(outW)

            val nm = ctx.getSystemService(NotificationManager::class.java)
            val granted = nm.isNotificationListenerAccessGranted(
                ComponentName(ctx, MediaListenerService::class.java)
            )

            val title = when {
                !granted -> "Дай доступ к уведомлениям"
                MusicState.title.isEmpty() -> "Ничего не играет"
                else -> MusicState.title
            }
            val artist = when {
                !granted -> "Нажми на виджет"
                MusicState.title.isEmpty() -> "Включи музыку"
                MusicState.artist.isEmpty() -> "—"
                else -> MusicState.artist
            }

            val layers = MusicRenderer.render(
                ctx, wDp.toFloat(), hDp.toFloat(), outW, outH,
                MusicRenderer.Input(
                    title, artist, MusicState.cover, MusicState.playing,
                    MusicState.posMs, MusicState.durMs, Store.halloweenActive(ctx)
                )
            )
            views.setImageViewBitmap(R.id.l_deco, layers.deco)
            views.setImageViewBitmap(R.id.l_pbg, layers.pbg)
            views.setImageViewBitmap(R.id.l_trk, layers.trk)
            views.setImageViewBitmap(R.id.l_fg, layers.fg)
            views.setImageViewBitmap(R.id.l_sub, layers.sub)
            views.setImageViewBitmap(R.id.l_pf, layers.pf)

            views.setImageViewResource(
                R.id.btn_play,
                if (MusicState.playing) R.drawable.ic_pause else R.drawable.ic_play
            )
            // играет — «таблетка», пауза — скруглённый прямоугольник
            views.setInt(
                R.id.btn_play, "setBackgroundResource",
                if (MusicState.playing) R.drawable.music_btn_play_on else R.drawable.music_btn_play_off
            )

            views.setOnClickPendingIntent(R.id.btn_prev, action(ctx, ACTION_PREV, 1))
            views.setOnClickPendingIntent(R.id.btn_play, action(ctx, ACTION_PLAY, 2))
            views.setOnClickPendingIntent(R.id.btn_next, action(ctx, ACTION_NEXT, 3))

            if (!granted) {
                val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                views.setOnClickPendingIntent(
                    R.id.m_root,
                    PendingIntent.getActivity(ctx, 4, i, PendingIntent.FLAG_IMMUTABLE)
                )
            }

            mgr.updateAppWidget(id, views)
        }
    }
}
