package com.example.duowidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews
import kotlin.math.max

class PhotoWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onAppWidgetOptionsChanged(
        ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        update(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { Store.delete(ctx, it) }
    }

    companion object {
        private const val MAX_SIDE = 800 // лимит памяти для RemoteViews

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_photo)

            val src = Store.loadSource(ctx, id)
            if (src != null) {
                val o = mgr.getAppWidgetOptions(id)
                val wDp = max(o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250), 40)
                val hDp = max(o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 120), 40)
                val ratio = wDp.toFloat() / hDp
                val outW: Int
                val outH: Int
                if (ratio >= 1f) { outW = MAX_SIDE; outH = (MAX_SIDE / ratio).toInt() }
                else { outH = MAX_SIDE; outW = (MAX_SIDE * ratio).toInt() }

                val s = Store.load(ctx, id)
                val mask = ImageEngine.mask(
                    src, max(outW, 1), max(outH, 1), s.offX, s.offY, s.contrast, s.invert
                )
                views.setImageViewBitmap(R.id.img, mask)
            }

            // тап по виджету — настройки
            val i = Intent(ctx, ConfigActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                data = Uri.parse("duowidget://widget/$id")
            }
            val pi = PendingIntent.getActivity(
                ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, pi)

            mgr.updateAppWidget(id, views)
        }
    }
}
