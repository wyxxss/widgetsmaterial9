package com.example.duowidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun pin(cls: Class<*>) {
        val mgr = getSystemService(AppWidgetManager::class.java)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, cls), null, null)
        } else {
            Toast.makeText(this, "Долгий тап по рабочему столу → Виджеты → DuoWidget", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()

        val title = TextView(this).apply {
            text = "DuoWidget"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        val info = TextView(this).apply {
            text = "Виджеты в системных цветах Material You. Цвета меняются сами вместе с обоями и темой.\n\n" +
                "Фото — любое фото в дуотоне.\n" +
                "Музыка — крупная обложка-тыква, волна прогресса и летучая мышь. " +
                "Для неё нужно один раз дать доступ к уведомлениям."
            textSize = 16f
            setPadding(0, pad / 2, 0, pad)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
        }

        val hwBtn = Button(this)
        fun hwLabel() = "Хэллоуин: " + when (Store.halloweenMode(this)) {
            1 -> "всегда"
            2 -> "выкл"
            else -> "авто (24 окт — 1 ноя)"
        }
        hwBtn.text = hwLabel()
        hwBtn.setOnClickListener {
            Store.setHalloweenMode(this, (Store.halloweenMode(this) + 1) % 3)
            hwBtn.text = hwLabel()
            MusicWidgetProvider.updateAll(this)
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(title)
            addView(info)
            addView(btn("Добавить фото-виджет") { pin(PhotoWidgetProvider::class.java) })
            addView(btn("Добавить музыкальный виджет") { pin(MusicWidgetProvider::class.java) })
            addView(hwBtn)
            addView(btn("Дать доступ к уведомлениям (для музыки)") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            })
        })
    }
}
