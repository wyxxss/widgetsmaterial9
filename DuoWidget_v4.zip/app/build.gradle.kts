plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.duowidget"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.duowidget"
        minSdk = 31   // системные динамические цвета (Material You) есть с Android 12
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    // Remote Compose (alpha) — анимации считает лаунчер, а не приложение
    val rc = "1.0.0-alpha21"
    implementation("androidx.compose.remote:remote-core:$rc")
    implementation("androidx.compose.remote:remote-creation:$rc")
    implementation("androidx.compose.remote:remote-creation-core:$rc")
    implementation("androidx.compose.remote:remote-creation-android:$rc")
    implementation("androidx.compose.remote:remote-creation-compose:$rc")
}
